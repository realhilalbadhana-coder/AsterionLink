Asterion Link 5.0 — fresh source. Wi-Fi Direct local chat, profile sharing, file transfer, splash/logo and message sound.
