package com.asterion.link;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.net.Uri;
import android.net.wifi.p2p.*;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.FrameLayout;
import android.widget.*;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    static final int REQ_NEARBY=41, REQ_FILE=42, REQ_PROFILE_PHOTO=43, PORT=8988;
    final int PAPER=Color.rgb(247,248,250), SURFACE=Color.WHITE, INK=Color.rgb(22,25,29), MUTED=Color.rgb(105,112,120), LINE=Color.rgb(225,229,233), ACCENT=Color.rgb(18,140,126), SOFT=Color.rgb(231,248,243);

    WifiP2pManager manager; WifiP2pManager.Channel channel; BroadcastReceiver receiver;
    final ArrayList<WifiP2pDevice> peers=new ArrayList<>();
    LinearLayout root,body,peerList,messages,bottom;
    TextView status,peerCount,connection,homeName,homeSub,chatPeerTitle;
    ImageView chatAvatar;
    EditText input;
    ScrollView chatScroll;
    Socket socket; DataInputStream in; DataOutputStream out; ServerSocket serverSocket;
    ExecutorService io=Executors.newCachedThreadPool();
    Handler main=new Handler(Looper.getMainLooper());
    volatile boolean connected=false, transportStarted=false, streamsReady=false, profileSent=false;
    boolean inChat=false;
    String peerName="Asterion device"; byte[] peerPhoto=null;
    String myName=""; byte[] myPhoto=null;
    SharedPreferences prefs;
    SoundPool soundPool; int messageSound=0;

    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    LinearLayout.LayoutParams lp(int w,int h,int weight){return new LinearLayout.LayoutParams(w,h,weight);}
    void margin(View v,int l,int t,int r,int b){ViewGroup.LayoutParams raw=v.getLayoutParams();if(raw instanceof LinearLayout.LayoutParams){LinearLayout.LayoutParams p=(LinearLayout.LayoutParams)raw;p.setMargins(dp(l),dp(t),dp(r),dp(b));v.setLayoutParams(p);}}

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(PAPER);getWindow().setNavigationBarColor(PAPER);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);prefs=getSharedPreferences("asterion_profile",MODE_PRIVATE);loadProfile();setupSound();showSplash();}

    void showSplash(){
        LinearLayout s=new LinearLayout(this);s.setOrientation(LinearLayout.VERTICAL);s.setGravity(Gravity.CENTER);s.setBackgroundColor(SURFACE);
        TextView logo=tv("A",58,Color.WHITE);logo.setGravity(Gravity.CENTER);logo.setTypeface(null,1);logo.setBackground(round(ACCENT,28));s.addView(logo,lp(dp(94),dp(94)));margin(logo,0,0,0,22);
        TextView n=tv("Asterion Link",25,INK);n.setGravity(Gravity.CENTER);n.setTypeface(null,1);s.addView(n,lp(-1,dp(36)));
        TextView sub=tv("Private local messaging",13,MUTED);sub.setGravity(Gravity.CENTER);s.addView(sub,lp(-1,dp(28)));
        setContentView(s);
        main.postDelayed(()->{if(myName.isEmpty())buildProfileSetup(false);else buildShell();},850);
    }

    GradientDrawable round(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    GradientDrawable strokeBg(int fill,int stroke,float radius){GradientDrawable g=round(fill,radius);g.setStroke(dp(1),stroke);return g;}

    void setupSound(){AudioAttributes a=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();soundPool=new SoundPool.Builder().setMaxStreams(2).setAudioAttributes(a).build();messageSound=soundPool.load(this,R.raw.message_pop,1);}
    void playMessageSound(){if(soundPool!=null&&messageSound!=0)soundPool.play(messageSound,0.55f,0.55f,1,0,1f);}

    void loadProfile(){myName=prefs.getString("name","");String path=prefs.getString("photo_path","");if(!path.isEmpty()){try{myPhoto=readAll(new FileInputStream(path));}catch(Exception ignored){myPhoto=null;}}}
    void saveProfile(String name){myName=name.trim();prefs.edit().putString("name",myName).apply();if(myPhoto!=null){try{File f=new File(getFilesDir(),"profile.jpg");try(FileOutputStream o=new FileOutputStream(f)){o.write(myPhoto);}prefs.edit().putString("photo_path",f.getAbsolutePath()).apply();}catch(Exception ignored){}}}
    byte[] readAll(InputStream is)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int n;while((n=is.read(x))!=-1)b.write(x,0,n);return b.toByteArray();}

    void buildProfileSetup(boolean editing){
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(24),dp(34),dp(24),dp(24));page.setBackgroundColor(PAPER);
        if(editing){TextView back=tv("‹",34,INK);back.setGravity(Gravity.CENTER);page.addView(back,lp(dp(45),dp(45)));back.setOnClickListener(v->buildShell());}
        TextView title=tv(editing?"Edit your profile":"Create your profile",28,INK);title.setTypeface(null,1);page.addView(title,lp(-1,dp(42)));margin(title,0,editing?8:42,0,0);
        TextView sub=tv("This name and photo are shared only with devices you connect to.",14,MUTED);sub.setLineSpacing(2,1f);page.addView(sub,lp(-1,dp(52)));margin(sub,0,4,0,0);
        FrameLayout photoBox=new FrameLayout(this);photoBox.setPadding(0,dp(8),0,dp(8));ImageView photo=new ImageView(this);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);photo.setBackground(round(ACCENT,60));if(myPhoto!=null)setImage(photo,myPhoto);else{TextView a=tv("A",42,Color.WHITE);a.setGravity(Gravity.CENTER);a.setTypeface(null,1);photoBox.addView(a,lp(dp(116),dp(116)));}if(photoBox.getChildCount()==0)photoBox.addView(photo,lp(dp(116),dp(116)));else photoBox.addView(photo,lp(dp(116),dp(116)));photo.setVisibility(myPhoto==null?View.GONE:View.VISIBLE);photoBox.setGravity(Gravity.CENTER);page.addView(photoBox,lp(-1,dp(140)));
        TextView choose=tv("Add profile photo",13,ACCENT);choose.setGravity(Gravity.CENTER);choose.setTypeface(null,1);page.addView(choose,lp(-1,dp(30)));choose.setOnClickListener(v->pickProfilePhoto());
        EditText name=new EditText(this);name.setSingleLine(true);name.setText(myName);name.setTextSize(16);name.setTextColor(INK);name.setHintTextColor(MUTED);name.setHint("Your name");name.setPadding(dp(16),0,dp(16),0);name.setBackground(strokeBg(SURFACE,LINE,16));page.addView(name,lp(-1,dp(54)));margin(name,0,22,0,0);
        TextView note=tv("You can change this later from Settings.",12,MUTED);page.addView(note,lp(-1,dp(28)));margin(note,0,5,0,0);
        TextView save=tv(editing?"SAVE CHANGES":"CONTINUE",14,Color.WHITE);save.setGravity(Gravity.CENTER);save.setTypeface(null,1);save.setBackground(round(ACCENT,18));page.addView(save,lp(-1,dp(54)));margin(save,0,18,0,0);save.setOnClickListener(v->{String n=name.getText().toString().trim();if(n.isEmpty()){name.setError("Enter your name");return;}saveProfile(n);if(editing)buildShell();else buildShell();});
        setContentView(page);
    }

    void pickProfilePhoto(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,REQ_PROFILE_PHOTO);}

    void buildShell(){
        if(manager==null)initP2p();
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(PAPER);root.setPadding(dp(18),dp(8),dp(18),0);setContentView(root);buildHeader();body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);root.addView(body,lp(-1,0,1));buildHome();buildBottom();
    }

    void buildHeader(){
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(0,dp(2),0,dp(8));
        ImageView avatar=new ImageView(this);avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);avatar.setBackground(round(ACCENT,24));if(myPhoto!=null)setImage(avatar,myPhoto);else avatar.setImageDrawable(null);header.addView(avatar,lp(dp(44),dp(44)));margin(avatar,0,0,11,0);
        LinearLayout names=new LinearLayout(this);names.setOrientation(LinearLayout.VERTICAL);TextView name=tv("Asterion Link",20,INK);name.setTypeface(null,1);names.addView(name,lp(-1,dp(27)));homeName=tv(myName,12,MUTED);names.addView(homeName,lp(-1,dp(20)));header.addView(names,lp(0,dp(48),1));
        TextView scan=tv("⌁",26,INK);scan.setGravity(Gravity.CENTER);scan.setBackground(strokeBg(SURFACE,LINE,18));header.addView(scan,lp(dp(46),dp(44)));margin(scan,4,0,0,0);scan.setOnClickListener(v->discover());
        TextView more=tv("⋮",26,INK);more.setGravity(Gravity.CENTER);header.addView(more,lp(dp(34),dp(44)));more.setOnClickListener(v->showInfo());root.addView(header,lp(-1,dp(60)));
        LinearLayout search=new LinearLayout(this);search.setGravity(Gravity.CENTER_VERTICAL);search.setPadding(dp(15),0,dp(12),0);search.setBackground(round(Color.rgb(238,241,243),28));TextView icon=tv("⌕",25,MUTED);search.addView(icon,lp(dp(32),dp(48)));TextView hint=tv("Search nearby devices",14,MUTED);search.addView(hint,lp(0,dp(48),1));root.addView(search,lp(-1,dp(48)));margin(search,0,0,0,10);
    }

    void buildHome(){inChat=false;body.removeAllViews();
        LinearLayout intro=new LinearLayout(this);intro.setOrientation(LinearLayout.VERTICAL);intro.setPadding(dp(2),dp(6),dp(2),dp(4));TextView h=tv("Nearby devices",26,INK);h.setTypeface(null,1);intro.addView(h,lp(-1,dp(37)));status=tv("Ready to discover devices",13,MUTED);intro.addView(status,lp(-1,dp(24)));body.addView(intro,lp(-1,dp(68)));
        LinearLayout section=new LinearLayout(this);section.setGravity(Gravity.CENTER_VERTICAL);TextView s=tv("AVAILABLE",11,MUTED);s.setTypeface(null,1);section.addView(s,lp(0,dp(28),1));peerCount=tv(String.valueOf(peers.size()),11,ACCENT);peerCount.setGravity(Gravity.CENTER);peerCount.setBackground(strokeBg(SURFACE,LINE,16));section.addView(peerCount,lp(dp(34),dp(28)));body.addView(section,lp(-1,dp(34)));margin(section,0,2,0,5);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);peerList=new LinearLayout(this);peerList.setOrientation(LinearLayout.VERTICAL);scroll.addView(peerList);body.addView(scroll,lp(-1,0,1));renderPeers();
    }

    void renderPeers(){if(peerList==null)return;peerList.removeAllViews();if(peerCount!=null)peerCount.setText(String.valueOf(peers.size()));if(peers.isEmpty()){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);box.setPadding(dp(24),dp(25),dp(24),dp(25));TextView orb=tv("A",32,ACCENT);orb.setGravity(Gravity.CENTER);orb.setTypeface(null,1);orb.setBackground(strokeBg(SURFACE,LINE,36));box.addView(orb,lp(dp(72),dp(72)));margin(orb,0,0,0,14);TextView t=tv("No devices nearby",18,INK);t.setGravity(Gravity.CENTER);t.setTypeface(null,1);box.addView(t,lp(-1,dp(30)));TextView d=tv("Open Asterion Link on the other phone, then tap the scan button.",13,MUTED);d.setGravity(Gravity.CENTER);d.setLineSpacing(2,1f);box.addView(d,lp(-1,dp(55)));TextView b=tv("SCAN FOR DEVICES",12,Color.WHITE);b.setGravity(Gravity.CENTER);b.setTypeface(null,1);b.setBackground(round(ACCENT,18));box.addView(b,lp(dp(160),dp(44)));margin(b,0,8,0,0);b.setOnClickListener(v->discover());peerList.addView(box,lp(-1,dp(245)));return;}
        for(WifiP2pDevice dev:peers){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(13),dp(10),dp(10),dp(10));row.setBackground(strokeBg(SURFACE,LINE,18));margin(row,0,0,0,8);TextView avatar=tv("A",18,ACCENT);avatar.setGravity(Gravity.CENTER);avatar.setTypeface(null,1);avatar.setBackground(round(SOFT,25));row.addView(avatar,lp(dp(50),dp(50)));margin(avatar,0,0,12,0);LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);String dn=(dev.deviceName==null||dev.deviceName.isEmpty())?"Asterion device":dev.deviceName;TextView n=tv(dn,16,INK);n.setTypeface(null,1);info.addView(n,lp(-1,dp(25)));TextView a=tv("Tap to connect locally",12,MUTED);info.addView(a,lp(-1,dp(22)));row.addView(info,lp(0,dp(54),1));TextView c=tv("›",28,ACCENT);c.setGravity(Gravity.CENTER);row.addView(c,lp(dp(38),dp(50)));row.setOnClickListener(v->connect(dev));peerList.addView(row,lp(-1,dp(72)));}
    }

    void buildBottom(){bottom=new LinearLayout(this);bottom.setGravity(Gravity.CENTER);bottom.setPadding(0,dp(6),0,dp(7));bottom.setBackgroundColor(SURFACE);addTab("Chats","◉",true,v->buildHome());addTab("Nearby","⌁",false,v->discover());addTab("Files","□",false,v->showTransfers());addTab("Profile","○",false,v->buildProfileSetup(true));root.addView(bottom,lp(-1,dp(66)));}
    void addTab(String label,String glyph,boolean active,View.OnClickListener click){LinearLayout tab=new LinearLayout(this);tab.setOrientation(LinearLayout.VERTICAL);tab.setGravity(Gravity.CENTER);TextView g=tv(glyph,21,active?ACCENT:MUTED);g.setGravity(Gravity.CENTER);tab.addView(g,lp(-1,dp(28)));TextView l=tv(label,10,active?ACCENT:MUTED);l.setGravity(Gravity.CENTER);tab.addView(l,lp(-1,dp(22)));tab.setOnClickListener(click);bottom.addView(tab,lp(0,dp(56),1));}

    void showChat(){inChat=true;body.removeAllViews();LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);TextView back=tv("‹",34,INK);back.setGravity(Gravity.CENTER);head.addView(back,lp(dp(42),dp(52)));back.setOnClickListener(v->buildHome());ImageView av=new ImageView(this);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setBackground(round(ACCENT,22));if(peerPhoto!=null)setImage(av,peerPhoto);chatAvatar=av;head.addView(av,lp(dp(44),dp(44)));margin(av,0,0,10,0);LinearLayout hi=new LinearLayout(this);hi.setOrientation(LinearLayout.VERTICAL);TextView n=tv(peerName,17,INK);n.setTypeface(null,1);chatPeerTitle=n;hi.addView(n,lp(-1,dp(25)));connection=tv(connected?"Connected locally":"Connecting…",11,ACCENT);hi.addView(connection,lp(-1,dp(21)));head.addView(hi,lp(0,dp(52),1));TextView dot=tv("•",28,ACCENT);dot.setGravity(Gravity.CENTER);head.addView(dot,lp(dp(30),dp(48)));body.addView(head,lp(-1,dp(60)));
        chatScroll=new ScrollView(this);chatScroll.setFillViewport(true);messages=new LinearLayout(this);messages.setOrientation(LinearLayout.VERTICAL);messages.setPadding(dp(4),dp(10),dp(4),dp(8));chatScroll.addView(messages);body.addView(chatScroll,lp(-1,0,1));
        LinearLayout composer=new LinearLayout(this);composer.setGravity(Gravity.CENTER_VERTICAL);input=new EditText(this);input.setSingleLine(true);input.setTextSize(15);input.setTextColor(INK);input.setHintTextColor(MUTED);input.setHint("Message");input.setPadding(dp(15),0,dp(12),0);input.setBackground(strokeBg(SURFACE,LINE,25));composer.addView(input,lp(0,50,1));TextView attach=tv("+",25,INK);attach.setGravity(Gravity.CENTER);composer.addView(attach,lp(dp(45),dp(50)));attach.setOnClickListener(v->pickFile());TextView send=tv("➤",19,Color.WHITE);send.setGravity(Gravity.CENTER);send.setBackground(round(ACCENT,24));composer.addView(send,lp(dp(48),dp(48)));send.setOnClickListener(v->sendText());body.addView(composer,lp(-1,dp(60)));margin(composer,0,5,0,4);
        if(messages.getChildCount()==0)addMessage("System","Local link ready. No mobile data required.",false);
    }

    void addMessage(String who,String text,boolean mine){if(messages==null)return;LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setGravity(mine?Gravity.END:Gravity.START);TextView m=tv(text,14,INK);m.setPadding(dp(13),dp(9),dp(13),dp(9));m.setMaxWidth(dp(300));m.setBackgroundResource(mine?R.drawable.bubble_me:R.drawable.bubble_other);wrap.addView(m);TextView meta=tv(who,9,MUTED);meta.setGravity(mine?Gravity.RIGHT:Gravity.LEFT);wrap.addView(meta,lp(-2,dp(17)));messages.addView(wrap,lp(-1,-2));margin(wrap,3,4,3,4);main.post(()->{if(chatScroll!=null)chatScroll.fullScroll(View.FOCUS_DOWN);});}

    void showTransfers(){body.removeAllViews();TextView h=tv("Transfers",27,INK);h.setTypeface(null,1);body.addView(h,lp(-1,dp(45)));TextView sub=tv("Files sent or received through your local link",13,MUTED);body.addView(sub,lp(-1,dp(28)));LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER);card.setBackground(strokeBg(SURFACE,LINE,20));TextView a=tv("□",35,ACCENT);a.setGravity(Gravity.CENTER);card.addView(a,lp(-1,dp(55)));TextView t=tv("No transfers yet",17,INK);t.setGravity(Gravity.CENTER);t.setTypeface(null,1);card.addView(t,lp(-1,dp(32)));TextView d=tv("Files will appear here after a local transfer.",13,MUTED);d.setGravity(Gravity.CENTER);card.addView(d,lp(-1,dp(45)));body.addView(card,lp(-1,dp(220)));margin(card,0,12,0,0);}
    void showInfo(){new AlertDialog.Builder(this).setTitle("Asterion Link").setMessage("Private local messaging over Wi‑Fi Direct.\n\nNo SIM or mobile internet is required.\n\nVersion 4.0").setPositiveButton("OK",null).setNeutralButton("Edit profile",(d,w)->buildProfileSetup(true)).show();}

    void initP2p(){manager=(WifiP2pManager)getSystemService(WIFI_P2P_SERVICE);channel=manager.initialize(this,getMainLooper(),()->{transportStarted=false;setStatus("Connection channel reset. Scan again.");});receiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){String a=i.getAction();if(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION.equals(a)){int s=i.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE,-1);setStatus(s==WifiP2pManager.WIFI_P2P_STATE_ENABLED?"Ready to discover devices":"Wi‑Fi Direct is unavailable");}else if(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(a)){if(hasP2pPermission())requestPeers();}else if(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(a)){requestConnection();}}};IntentFilter f=new IntentFilter();f.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);f.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);f.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);f.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_EXPORTED);else registerReceiver(receiver,f);}
    boolean hasP2pPermission(){return Build.VERSION.SDK_INT<33?checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED:checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES)==PackageManager.PERMISSION_GRANTED;}
    void discover(){if(!hasP2pPermission()){if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{Manifest.permission.NEARBY_WIFI_DEVICES},REQ_NEARBY);else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ_NEARBY);return;}peers.clear();renderPeers();setStatus("Looking for nearby devices…");manager.discoverPeers(channel,new WifiP2pManager.ActionListener(){public void onSuccess(){setStatus("Discovery active");}public void onFailure(int r){setStatus("Discovery failed: "+reason(r));}});}
    void requestPeers(){manager.requestPeers(channel,list->{peers.clear();peers.addAll(list.getDeviceList());renderPeers();});}
    String reason(int r){return r==WifiP2pManager.P2P_UNSUPPORTED?"P2P unsupported":r==WifiP2pManager.BUSY?"Wi‑Fi Direct busy":"Try again";}
    void connect(WifiP2pDevice dev){if(!hasP2pPermission()){discover();return;}peerName=(dev.deviceName==null||dev.deviceName.isEmpty())?"Asterion device":dev.deviceName;peerPhoto=null;transportStarted=false;streamsReady=false;closeSocketOnly();setStatus("Connecting…");WifiP2pConfig cfg=new WifiP2pConfig();cfg.deviceAddress=dev.deviceAddress;cfg.wps.setup=android.net.wifi.WpsInfo.PBC;manager.connect(channel,cfg,new WifiP2pManager.ActionListener(){public void onSuccess(){setStatus("Connection request sent");}public void onFailure(int r){setStatus("Connection failed: "+reason(r));}});}
    void requestConnection(){if(!hasP2pPermission())return;manager.requestConnectionInfo(channel,info->{if(info!=null&&info.groupFormed){connected=true;setStatus("Connected locally");if(peerName.isEmpty())peerName="Asterion device";if(!inChat)showChat();else updateChatHeader();if(!transportStarted){transportStarted=true;if(info.isGroupOwner)startServer();else if(info.groupOwnerAddress!=null)startClient(info.groupOwnerAddress.getHostAddress());}}else{connected=false;transportStarted=false;streamsReady=false;closeSocketOnly();setStatus("Waiting for local connection");}});}

    void startServer(){io.execute(()->{try{serverSocket=new ServerSocket(null);serverSocket.setReuseAddress(true);serverSocket.bind(new InetSocketAddress(PORT));while(connected&&!io.isShutdown()){Socket s=serverSocket.accept();if(socket!=null&&!socket.isClosed())try{socket.close();}catch(Exception ignored){}socket=s;setupStreams();streamsReady=true;sendProfile();main.post(()->setStatus("Connected • ready"));readLoop();streamsReady=false;if(connected){main.post(()->setStatus("Link waiting for reconnect…"));}}}catch(Exception e){if(connected)main.post(()->setStatus("Local link interrupted"));}finally{try{if(serverSocket!=null)serverSocket.close();}catch(Exception ignored){}}});}
    void startClient(String host){io.execute(()->{for(int n=0;n<15&&connected;n++){try{Socket s=new Socket();s.connect(new InetSocketAddress(host,PORT),2200);socket=s;setupStreams();streamsReady=true;sendProfile();main.post(()->setStatus("Connected • ready"));readLoop();streamsReady=false;if(connected){try{Thread.sleep(700);}catch(Exception ignored){}}return;}catch(Exception e){try{Thread.sleep(500);}catch(Exception ignored){}}}if(connected)main.post(()->setStatus("Could not open local link"));});}
    synchronized void setupStreams()throws IOException{in=new DataInputStream(new BufferedInputStream(socket.getInputStream()));out=new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));profileSent=false;}
    synchronized void sendProfile(){if(out==null||profileSent)return;try{byte[] name=myName.getBytes(StandardCharsets.UTF_8);byte[] photo=myPhoto==null?new byte[0]:myPhoto;out.writeByte(3);out.writeInt(name.length);out.write(name);out.writeInt(photo.length);if(photo.length>0)out.write(photo);out.flush();profileSent=true;}catch(Exception e){}}

    void readLoop(){try{while(connected&&in!=null){int type=in.readByte();if(type==1){int len=in.readInt();if(len<0||len>2_000_000)throw new IOException("bad message");byte[] b=new byte[len];in.readFully(b);String s=new String(b,StandardCharsets.UTF_8);main.post(()->{addMessage(peerName,s,false);playMessageSound();});}else if(type==2){long size=in.readLong();int nl=in.readInt();if(size<0||size>2_000_000_000L||nl<0||nl>10000)throw new IOException("bad file header");byte[] nb=new byte[nl];in.readFully(nb);String name=new String(nb,StandardCharsets.UTF_8);receiveFile(name,size);}else if(type==3){int nl=in.readInt();if(nl<0||nl>1000)throw new IOException("bad profile");byte[] nb=new byte[nl];in.readFully(nb);int pl=in.readInt();if(pl<0||pl>5_000_000)throw new IOException("bad photo");byte[] pb=new byte[pl];if(pl>0)in.readFully(pb);String name=new String(nb,StandardCharsets.UTF_8);main.post(()->{peerName=name.isEmpty()?"Asterion device":name;peerPhoto=pb.length==0?null:pb;updateChatHeader();});}}}catch(Exception e){closeSocketOnly();if(connected)main.post(()->setStatus("Link interrupted • reconnecting…"));}}
    void updateChatHeader(){if(chatPeerTitle!=null)chatPeerTitle.setText(peerName);if(chatAvatar!=null){chatAvatar.setImageDrawable(null);if(peerPhoto!=null)setImage(chatAvatar,peerPhoto);}if(connection!=null)connection.setText(connected?"Connected locally":"Disconnected");}

    void sendText(){String s=input==null?"":input.getText().toString().trim();if(s.isEmpty()||out==null||!streamsReady){if(status!=null)setStatus("Connect before sending");return;}input.setText("");io.execute(()->{try{byte[] b=s.getBytes(StandardCharsets.UTF_8);synchronized(this){out.writeByte(1);out.writeInt(b.length);out.write(b);out.flush();}main.post(()->addMessage("You",s,true));}catch(Exception e){main.post(()->setStatus("Message could not be sent"));}});}
    void pickFile(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_FILE);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==REQ_FILE&&c==RESULT_OK&&d!=null&&d.getData()!=null)sendFile(d.getData());if(r==REQ_PROFILE_PHOTO&&c==RESULT_OK&&d!=null&&d.getData()!=null){try{myPhoto=normalizePhoto(readAll(getContentResolver().openInputStream(d.getData())));buildProfileSetup(true);}catch(Exception ignored){}}}
    void sendFile(Uri uri){if(out==null||!streamsReady)return;io.execute(()->{try{String name=getName(uri);long size=getSize(uri);byte[] nb=name.getBytes(StandardCharsets.UTF_8);synchronized(this){out.writeByte(2);out.writeLong(size);out.writeInt(nb.length);out.write(nb);try(InputStream is=getContentResolver().openInputStream(uri)){byte[] buf=new byte[64*1024];int n;while((n=is.read(buf))!=-1)out.write(buf,0,n);out.flush();}}main.post(()->addMessage("You","Sent file • "+name,true));}catch(Exception e){main.post(()->setStatus("File transfer failed"));}});}
    void receiveFile(String name,long size)throws Exception{InputStream src=in;OutputStream os;Uri dest;if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,"application/octet-stream");v.put(MediaStore.Downloads.RELATIVE_PATH,"Download/Asterion Link");dest=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(dest==null)throw new IOException("storage");os=getContentResolver().openOutputStream(dest);}else{File dir=new File(getExternalFilesDir(null),"Asterion Link");dir.mkdirs();os=new FileOutputStream(new File(dir,name));}long got=0;byte[] buf=new byte[64*1024];try(OutputStream outFile=os){while(got<size){int want=(int)Math.min(buf.length,size-got);int n=src.read(buf,0,want);if(n<0)throw new EOFException();outFile.write(buf,0,n);got+=n;}}main.post(()->addMessage("Received","Saved file • "+name,false));}
    String getName(Uri u){Cursor c=getContentResolver().query(u,new String[]{"_display_name"},null,null,null);if(c!=null)try{if(c.moveToFirst())return c.getString(0);}finally{c.close();}return "file";}
    long getSize(Uri u){Cursor c=getContentResolver().query(u,new String[]{"_size"},null,null,null);if(c!=null)try{if(c.moveToFirst())return c.getLong(0);}finally{c.close();}return 0;}
    void setImage(ImageView v,byte[] b){Bitmap x=BitmapFactory.decodeByteArray(b,0,b.length);if(x!=null)v.setImageBitmap(x);}

    byte[] normalizePhoto(byte[] raw)throws IOException{
        Bitmap src=BitmapFactory.decodeByteArray(raw,0,raw.length);
        if(src==null)throw new IOException("invalid image");
        int max=512; float scale=Math.min(1f,Math.min(max/(float)src.getWidth(),max/(float)src.getHeight()));
        int w=Math.max(1,Math.round(src.getWidth()*scale)), h=Math.max(1,Math.round(src.getHeight()*scale));
        Bitmap outBmp=Bitmap.createScaledBitmap(src,w,h,true); ByteArrayOutputStream out=new ByteArrayOutputStream();
        outBmp.compress(Bitmap.CompressFormat.JPEG,82,out); if(outBmp!=src)outBmp.recycle(); src.recycle(); return out.toByteArray();
    }

    void closeSocketOnly(){try{if(socket!=null)socket.close();}catch(Exception ignored){}socket=null;in=null;out=null;streamsReady=false;}
    void setStatus(String s){main.post(()->{if(status!=null)status.setText(s);if(connection!=null&&s.toLowerCase().contains("disconnected"))connection.setText("Disconnected");});}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_NEARBY){if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)discover();else setStatus("Nearby-device permission is required");}}
    @Override public void onBackPressed(){if(body!=null&&messages!=null&&messages.getParent()!=null){buildHome();return;}super.onBackPressed();}
    @Override protected void onDestroy(){super.onDestroy();connected=false;transportStarted=false;try{if(receiver!=null)unregisterReceiver(receiver);}catch(Exception ignored){}try{if(serverSocket!=null)serverSocket.close();}catch(Exception ignored){}closeSocketOnly();if(soundPool!=null)soundPool.release();io.shutdownNow();}
}
