# Asterion Link v3

Fresh UI rebuild inspired by the layout language of modern messaging apps, without copying reference text or branding.

Features retained: Wi-Fi Direct discovery, P2P connection, local text chat and file transfer.

Build from GitHub Actions on a phone: push/upload this project, then run the `Build Asterion Link v3` workflow and download the APK artifact.
