package com.asterion.link;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.net.wifi.p2p.*;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    static final int REQ_NEARBY=41, REQ_FILE=42, PORT=8988;
    final int PAPER=Color.rgb(247,248,250), SURFACE=Color.WHITE, INK=Color.rgb(23,25,28), MUTED=Color.rgb(115,119,125), LINE=Color.rgb(229,231,234), ACCENT=Color.rgb(18,140,126);
    WifiP2pManager manager; WifiP2pManager.Channel channel; BroadcastReceiver receiver;
    final ArrayList<WifiP2pDevice> peers=new ArrayList<>();
    LinearLayout root, body, peerList, messages, bottom;
    TextView pageTitle, status, peerCount, connection, emptyTitle, emptySub;
    EditText input; ScrollView chatScroll;
    Socket socket; DataInputStream in; DataOutputStream out; ExecutorService io=Executors.newCachedThreadPool();
    volatile boolean connected=false; String peerName=""; Handler main=new Handler(Looper.getMainLooper());

    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    LinearLayout.LayoutParams lp(int w,int h,int weight){return new LinearLayout.LayoutParams(w,h,weight);}
    void margin(View v,int l,int t,int r,int b){ViewGroup.LayoutParams raw=v.getLayoutParams();if(raw instanceof LinearLayout.LayoutParams){LinearLayout.LayoutParams p=(LinearLayout.LayoutParams)raw;p.setMargins(dp(l),dp(t),dp(r),dp(b));v.setLayoutParams(p);}}

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(PAPER);getWindow().setNavigationBarColor(PAPER);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);buildShell();initP2p();}

    void buildShell(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(PAPER);root.setPadding(dp(18),dp(8),dp(18),0);setContentView(root);
        buildHeader();
        body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);root.addView(body,lp(-1,0,1));
        buildHome();
        buildBottom();
    }

    void buildHeader(){
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(0,dp(2),0,dp(8));
        LinearLayout brand=new LinearLayout(this);brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark=tv("A",20,Color.WHITE);mark.setGravity(Gravity.CENTER);mark.setTypeface(null,1);mark.setBackgroundResource(R.drawable.pill);brand.addView(mark,lp(dp(42),dp(42)));
        LinearLayout names=new LinearLayout(this);names.setOrientation(LinearLayout.VERTICAL);names.setPadding(dp(10),0,0,0);
        TextView name=tv("Asterion",21,ACCENT);name.setTypeface(null,1);names.addView(name,lp(-1,dp(26)));
        TextView sub=tv("LINK",10,MUTED);sub.setTypeface(null,1);names.addView(sub,lp(-1,dp(18)));
        brand.addView(names,lp(0,dp(48),1));header.addView(brand,lp(0,dp(52),1));
        TextView scan=tv("⌁",28,INK);scan.setGravity(Gravity.CENTER);scan.setBackgroundResource(R.drawable.outline);header.addView(scan,lp(dp(48),dp(44)));margin(scan,4,0,0,0);scan.setOnClickListener(v->discover());
        TextView more=tv("⋮",28,INK);more.setGravity(Gravity.CENTER);header.addView(more,lp(dp(38),dp(44)));more.setOnClickListener(v->showInfo());
        root.addView(header,lp(-1,dp(60)));
        LinearLayout search=new LinearLayout(this);search.setGravity(Gravity.CENTER_VERTICAL);search.setPadding(dp(15),0,dp(12),0);search.setBackgroundResource(R.drawable.search);
        TextView icon=tv("⌕",27,MUTED);search.addView(icon,lp(dp(34),dp(48)));TextView hint=tv("Search nearby links",15,MUTED);search.addView(hint,lp(0,dp(48),1));
        root.addView(search,lp(-1,dp(48)));margin(search,0,0,0,10);
    }

    void buildHome(){body.removeAllViews();
        LinearLayout intro=new LinearLayout(this);intro.setOrientation(LinearLayout.VERTICAL);intro.setPadding(dp(2),dp(6),dp(2),dp(5));
        pageTitle=tv("Nearby",27,INK);pageTitle.setTypeface(null,1);intro.addView(pageTitle,lp(-1,dp(38)));
        status=tv("Ready to discover devices",13,MUTED);intro.addView(status,lp(-1,dp(24)));
        body.addView(intro,lp(-1,dp(72)));
        LinearLayout section=new LinearLayout(this);section.setGravity(Gravity.CENTER_VERTICAL);TextView s=tv("AVAILABLE",11,MUTED);s.setTypeface(null,1);section.addView(s,lp(0,dp(28),1));peerCount=tv("0",11,ACCENT);peerCount.setGravity(Gravity.CENTER);peerCount.setBackgroundResource(R.drawable.outline);section.addView(peerCount,lp(dp(32),dp(28)));body.addView(section,lp(-1,dp(34)));margin(section,0,2,0,5);
        ScrollView scroll=new ScrollView(this);peerList=new LinearLayout(this);peerList.setOrientation(LinearLayout.VERTICAL);scroll.addView(peerList);body.addView(scroll,lp(-1,0,1));
        addEmpty();
    }

    void addEmpty(){peerList.removeAllViews();LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);box.setPadding(dp(28),dp(25),dp(28),dp(25));
        TextView orb=tv("A",32,ACCENT);orb.setGravity(Gravity.CENTER);orb.setTypeface(null,1);orb.setBackgroundResource(R.drawable.outline);box.addView(orb,lp(dp(72),dp(72)));margin(orb,0,0,0,14);
        emptyTitle=tv("Nothing nearby yet",17,INK);emptyTitle.setGravity(Gravity.CENTER);emptyTitle.setTypeface(null,1);box.addView(emptyTitle,lp(-1,dp(28)));
        emptySub=tv("Keep Asterion Link open on another phone and start discovery.",13,MUTED);emptySub.setGravity(Gravity.CENTER);box.addView(emptySub,lp(-1,dp(52)));
        TextView button=tv("DISCOVER",12,Color.WHITE);button.setGravity(Gravity.CENTER);button.setTypeface(null,1);button.setBackgroundResource(R.drawable.pill);box.addView(button,lp(dp(124),dp(44)));margin(button,0,8,0,0);button.setOnClickListener(v->discover());peerList.addView(box,lp(-1,dp(230)));
    }

    void renderPeers(){peerList.removeAllViews();peerCount.setText(String.valueOf(peers.size()));if(peers.isEmpty()){addEmpty();return;}
        for(WifiP2pDevice dev:peers){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(13),dp(10),dp(10),dp(10));row.setBackgroundResource(R.drawable.card);margin(row,0,0,0,8);
            TextView avatar=tv("A",18,ACCENT);avatar.setGravity(Gravity.CENTER);avatar.setTypeface(null,1);avatar.setBackgroundResource(R.drawable.outline);row.addView(avatar,lp(dp(50),dp(50)));margin(avatar,0,0,12,0);
            LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);TextView n=tv((dev.deviceName==null||dev.deviceName.isEmpty())?"Asterion device":dev.deviceName,16,INK);n.setTypeface(null,1);info.addView(n,lp(-1,dp(25)));TextView a=tv("Available for local connection",12,MUTED);info.addView(a,lp(-1,dp(22)));row.addView(info,lp(0,dp(54),1));
            TextView c=tv("›",28,ACCENT);c.setGravity(Gravity.CENTER);row.addView(c,lp(dp(42),dp(50)));row.setOnClickListener(v->connect(dev));peerList.addView(row,lp(-1,dp(72)));
        }
    }

    void buildBottom(){
        bottom=new LinearLayout(this);bottom.setGravity(Gravity.CENTER);bottom.setPadding(0,dp(6),0,dp(7));bottom.setBackgroundColor(SURFACE);
        addTab("Chats","◉",true,v->buildHome());addTab("Nearby","⌁",false,v->buildHome());addTab("Files","□",false,v->showTransfers());addTab("Settings","⚙",false,v->showInfo());root.addView(bottom,lp(-1,dp(66)));
    }
    void addTab(String label,String glyph,boolean active,View.OnClickListener click){LinearLayout tab=new LinearLayout(this);tab.setOrientation(LinearLayout.VERTICAL);tab.setGravity(Gravity.CENTER);TextView g=tv(glyph,21,active?ACCENT:MUTED);g.setGravity(Gravity.CENTER);tab.addView(g,lp(-1,dp(28)));TextView l=tv(label,10,active?ACCENT:MUTED);l.setGravity(Gravity.CENTER);tab.addView(l,lp(-1,dp(22)));tab.setOnClickListener(click);bottom.addView(tab,lp(0,dp(56),1));}

    void showChat(){body.removeAllViews();
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);TextView back=tv("‹",34,INK);back.setGravity(Gravity.CENTER);head.addView(back,lp(dp(42),dp(52)));back.setOnClickListener(v->buildHome());
        TextView av=tv("A",17,ACCENT);av.setGravity(Gravity.CENTER);av.setTypeface(null,1);av.setBackgroundResource(R.drawable.outline);head.addView(av,lp(dp(42),dp(42)));margin(av,0,0,10,0);
        LinearLayout hi=new LinearLayout(this);hi.setOrientation(LinearLayout.VERTICAL);TextView n=tv(peerName.isEmpty()?"Asterion device":peerName,17,INK);n.setTypeface(null,1);hi.addView(n,lp(-1,dp(25)));connection=tv("Connected locally",11,ACCENT);hi.addView(connection,lp(-1,dp(21)));head.addView(hi,lp(0,dp(52),1));
        TextView dot=tv("•",28,ACCENT);dot.setGravity(Gravity.CENTER);head.addView(dot,lp(dp(32),dp(48)));body.addView(head,lp(-1,dp(60)));
        chatScroll=new ScrollView(this);messages=new LinearLayout(this);messages.setOrientation(LinearLayout.VERTICAL);messages.setPadding(dp(4),dp(10),dp(4),dp(8));chatScroll.addView(messages);body.addView(chatScroll,lp(-1,0,1));
        LinearLayout composer=new LinearLayout(this);composer.setGravity(Gravity.CENTER_VERTICAL);input=new EditText(this);input.setSingleLine(true);input.setTextSize(15);input.setTextColor(INK);input.setHintTextColor(MUTED);input.setHint("Write a message");input.setBackgroundResource(R.drawable.input);composer.addView(input,lp(0,50,1));
        TextView attach=tv("+",25,INK);attach.setGravity(Gravity.CENTER);composer.addView(attach,lp(dp(45),dp(50)));attach.setOnClickListener(v->pickFile());
        TextView send=tv("➤",20,Color.WHITE);send.setGravity(Gravity.CENTER);send.setBackgroundResource(R.drawable.pill);composer.addView(send,lp(dp(48),dp(48)));send.setOnClickListener(v->sendText());body.addView(composer,lp(-1,dp(60)));margin(composer,0,5,0,4);
        addMessage("Connected", "Local link is ready. Messages do not need mobile data.", false);
    }

    void addMessage(String who,String text,boolean mine){if(messages==null)return;LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setGravity(mine?Gravity.END:Gravity.START);TextView m=tv(text,14,INK);m.setPadding(dp(13),dp(9),dp(13),dp(9));m.setBackgroundResource(mine?R.drawable.bubble_me:R.drawable.bubble_other);wrap.addView(m);TextView meta=tv(who,9,MUTED);meta.setGravity(mine?Gravity.RIGHT:Gravity.LEFT);wrap.addView(meta,lp(-2,dp(17)));messages.addView(wrap,lp(-1,-2));margin(wrap,3,4,3,4);main.post(()->chatScroll.fullScroll(View.FOCUS_DOWN));}

    void showTransfers(){body.removeAllViews();TextView h=tv("Transfers",27,INK);h.setTypeface(null,1);body.addView(h,lp(-1,dp(45)));TextView sub=tv("Files sent or received through Asterion Link",13,MUTED);body.addView(sub,lp(-1,dp(28)));LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER);card.setBackgroundResource(R.drawable.card);TextView a=tv("□",35,ACCENT);a.setGravity(Gravity.CENTER);card.addView(a,lp(-1,dp(55)));TextView t=tv("No transfers yet",17,INK);t.setGravity(Gravity.CENTER);t.setTypeface(null,1);card.addView(t,lp(-1,dp(32)));TextView d=tv("Files will appear here after a local transfer.",13,MUTED);d.setGravity(Gravity.CENTER);card.addView(d,lp(-1,dp(45)));body.addView(card,lp(-1,dp(220)));margin(card,0,12,0,0);}
    void showInfo(){new AlertDialog.Builder(this).setTitle("Asterion Link").setMessage("Offline local communication using Wi‑Fi Direct.\n\nVersion 3.0").setPositiveButton("OK",null).show();}

    void initP2p(){manager=(WifiP2pManager)getSystemService(WIFI_P2P_SERVICE);channel=manager.initialize(this,getMainLooper(),()->setStatus("Connection channel reset. Tap discovery again."));
        receiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){String a=i.getAction();if(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION.equals(a)){int s=i.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE,-1);setStatus(s==WifiP2pManager.WIFI_P2P_STATE_ENABLED?"Ready to discover devices":"Wi‑Fi Direct is unavailable");}else if(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(a)){if(hasP2pPermission())requestPeers();}else if(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(a)){requestConnection();}}};
        IntentFilter f=new IntentFilter();f.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);f.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);f.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);f.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_EXPORTED);else registerReceiver(receiver,f);
    }
    boolean hasP2pPermission(){return Build.VERSION.SDK_INT<33?checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED:checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES)==PackageManager.PERMISSION_GRANTED;}
    void discover(){if(!hasP2pPermission()){if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{Manifest.permission.NEARBY_WIFI_DEVICES},REQ_NEARBY);else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ_NEARBY);return;}peers.clear();renderPeers();setStatus("Looking for nearby devices…");manager.discoverPeers(channel,new WifiP2pManager.ActionListener(){public void onSuccess(){setStatus("Discovery active");}public void onFailure(int r){setStatus("Discovery failed: "+reason(r));}});}
    void requestPeers(){manager.requestPeers(channel,list->{peers.clear();peers.addAll(list.getDeviceList());renderPeers();});}
    String reason(int r){return r==WifiP2pManager.P2P_UNSUPPORTED?"P2P unsupported":r==WifiP2pManager.BUSY?"Wi‑Fi Direct busy":"Try again";}
    void connect(WifiP2pDevice dev){if(!hasP2pPermission()){discover();return;}peerName=dev.deviceName;setStatus("Connecting…");WifiP2pConfig cfg=new WifiP2pConfig();cfg.deviceAddress=dev.deviceAddress;cfg.wps.setup=android.net.wifi.WpsInfo.PBC;manager.connect(channel,cfg,new WifiP2pManager.ActionListener(){public void onSuccess(){setStatus("Connection request sent");}public void onFailure(int r){setStatus("Connection failed: "+reason(r));}});}
    void requestConnection(){if(!hasP2pPermission())return;manager.requestConnectionInfo(channel,info->{if(info!=null&&info.groupFormed){connected=true;setStatus("Connected locally");if(peerName.isEmpty())peerName="Asterion device";showChat();if(info.isGroupOwner)startServer();else startClient(info.groupOwnerAddress.getHostAddress());}});}
    void startServer(){io.execute(()->{try{ServerSocket ss=new ServerSocket(PORT);socket=ss.accept();ss.close();setupStreams();main.post(()->setStatus("Connected • ready"));readLoop();}catch(Exception e){main.post(()->setStatus("Local link interrupted"));}});}
    void startClient(String host){io.execute(()->{for(int n=0;n<10;n++){try{socket=new Socket();socket.connect(new InetSocketAddress(host,PORT),2500);setupStreams();main.post(()->setStatus("Connected • ready"));readLoop();return;}catch(Exception e){try{Thread.sleep(700);}catch(Exception ignored){}}}main.post(()->setStatus("Could not open local link"));});}
    synchronized void setupStreams()throws IOException{in=new DataInputStream(new BufferedInputStream(socket.getInputStream()));out=new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));}
    void readLoop(){try{while(true){int type=in.readByte();if(type==1){int len=in.readInt();byte[] b=new byte[len];in.readFully(b);String s=new String(b,StandardCharsets.UTF_8);main.post(()->addMessage(peerName,s,false));}else if(type==2){long size=in.readLong();int nl=in.readInt();byte[] nb=new byte[nl];in.readFully(nb);String name=new String(nb,StandardCharsets.UTF_8);receiveFile(name,size);}}}catch(Exception e){connected=false;main.post(()->setStatus("Disconnected"));}}
    void sendText(){String s=input==null?"":input.getText().toString().trim();if(s.isEmpty()||out==null)return;input.setText("");io.execute(()->{try{byte[] b=s.getBytes(StandardCharsets.UTF_8);synchronized(this){out.writeByte(1);out.writeInt(b.length);out.write(b);out.flush();}main.post(()->addMessage("You",s,true));}catch(Exception e){main.post(()->setStatus("Message could not be sent"));}});}
    void pickFile(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_FILE);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==REQ_FILE&&c==RESULT_OK&&d!=null&&d.getData()!=null)sendFile(d.getData());}
    void sendFile(Uri uri){if(out==null)return;io.execute(()->{try{String name=getName(uri);long size=getSize(uri);byte[] nb=name.getBytes(StandardCharsets.UTF_8);synchronized(this){out.writeByte(2);out.writeLong(size);out.writeInt(nb.length);out.write(nb);try(InputStream is=getContentResolver().openInputStream(uri)){byte[] buf=new byte[64*1024];int n;while((n=is.read(buf))!=-1){out.write(buf,0,n);}out.flush();}}main.post(()->addMessage("You","Sent file • "+name,true));}catch(Exception e){main.post(()->setStatus("File transfer failed"));}});}
    void receiveFile(String name,long size)throws Exception{InputStream src=in;OutputStream os;Uri dest;if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,"application/octet-stream");v.put(MediaStore.Downloads.RELATIVE_PATH,"Download/Asterion Link");dest=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(dest==null)throw new IOException("storage");os=getContentResolver().openOutputStream(dest);}else{File dir=new File(getExternalFilesDir(null),"Asterion Link");dir.mkdirs();os=new FileOutputStream(new File(dir,name));}long got=0;byte[] buf=new byte[64*1024];try(OutputStream outFile=os){while(got<size){int want=(int)Math.min(buf.length,size-got);int n=src.read(buf,0,want);if(n<0)throw new EOFException();outFile.write(buf,0,n);got+=n;}}main.post(()->addMessage("Received","Saved file • "+name,false));}
    String getName(Uri u){Cursor c=getContentResolver().query(u,new String[]{"_display_name"},null,null,null);if(c!=null)try{if(c.moveToFirst())return c.getString(0);}finally{c.close();}return "file";}
    long getSize(Uri u){Cursor c=getContentResolver().query(u,new String[]{"_size"},null,null,null);if(c!=null)try{if(c.moveToFirst())return c.getLong(0);}finally{c.close();}return 0;}
    void setStatus(String s){main.post(()->{if(status!=null)status.setText(s);});}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_NEARBY){if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)discover();else setStatus("Nearby-device permission is required");}}
    @Override protected void onDestroy(){super.onDestroy();try{if(receiver!=null)unregisterReceiver(receiver);}catch(Exception ignored){}try{if(socket!=null)socket.close();}catch(Exception ignored){}io.shutdownNow();}
}
