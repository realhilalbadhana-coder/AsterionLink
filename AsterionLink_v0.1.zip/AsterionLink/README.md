# Asterion Link v0.1

Mobile-first Android prototype for **internet-free Wi-Fi Direct chat + file transfer**.

## What this build does
- Discovers nearby Android phones using Wi-Fi Direct.
- Connects two phones without mobile data or an Internet connection.
- Sends live text messages over a TCP socket inside the Wi-Fi Direct group.
- Sends arbitrary files over the same local link.
- Saves received files into `Download/Asterion` on Android 10+.
- Shows transfer progress.

## What this build does NOT do yet
- End-to-end encryption is not implemented in v0.1.
- Multi-hop mesh routing is not implemented.
- Background service / notifications are not implemented.
- Multiple simultaneous peers are not implemented.

## Testing
Use two Android phones with Wi-Fi enabled. For Android peer discovery, keep Location mode ON. Install the same APK on both phones.

1. Open Asterion Link on both phones.
2. Allow Nearby Wi-Fi permission.
3. Keep the phones reasonably close.
4. Tap **Scan Devices** on both (one phone may be enough after discovery begins).
5. Tap the other Asterion device.
6. Accept the Android Wi-Fi Direct connection prompt if it appears.
7. When status says **CHAT CONNECTED**, send a message.
8. Tap **SEND FILE** to transfer a photo/video/document.

## Build on a phone with GitHub Actions
1. Create a GitHub repository and upload this whole project.
2. Wait for the `Build Asterion Link APK` workflow under **Actions** to finish.
3. Open the completed workflow run and download the artifact named `asterion-link-debug-apk`.
4. Extract the artifact and install `app-debug.apk` on both test phones.

The workflow installs Android SDK 36, uses JDK 17, and builds with Gradle 9.6 / Android Gradle Plugin 9.4.
