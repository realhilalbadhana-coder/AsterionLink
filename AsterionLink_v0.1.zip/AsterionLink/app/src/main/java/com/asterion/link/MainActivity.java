package com.asterion.link;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.location.LocationManager;
import android.net.Uri;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pDeviceList;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.NetworkInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity implements WifiP2pManager.ConnectionInfoListener {
    private static final int PORT = 8988;
    private static final int REQ_PERMISSIONS = 100;
    private static final int PICK_FILE = 200;

    private WifiP2pManager manager;
    private WifiP2pManager.Channel channel;
    private BroadcastReceiver receiver;
    private final ExecutorService io = Executors.newCachedThreadPool();

    private LinearLayout root;
    private LinearLayout peersBox;
    private TextView status;
    private TextView chat;
    private EditText messageInput;
    private Button sendButton;
    private Button fileButton;

    private final Object socketLock = new Object();
    private Socket socket;
    private DataInputStream input;
    private DataOutputStream output;
    private ServerSocket serverSocket;
    private volatile boolean connected = false;
    private boolean receiverRegistered = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        setupWifiP2p();
        requestNeededPermissions();
        registerP2pReceiver();
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 18, 20, 18);
        root.setBackgroundColor(Color.rgb(11, 14, 19));

        TextView title = text("ASTERION LINK", 22, Color.WHITE);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title, lp(LinearLayout.LayoutParams.MATCH_PARENT, 52));

        TextView subtitle = text("Offline Wi-Fi Direct chat + file transfer", 13, Color.rgb(154, 166, 178));
        root.addView(subtitle, lp(LinearLayout.LayoutParams.MATCH_PARENT, 30));

        status = text("Starting…", 14, Color.rgb(154, 166, 178));
        status.setPadding(12, 8, 12, 8);
        status.setBackgroundColor(Color.rgb(21, 26, 34));
        root.addView(status, lp(LinearLayout.LayoutParams.MATCH_PARENT, 48));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, 12, 0, 8);

        Button scan = button("SCAN DEVICES");
        scan.setOnClickListener(v -> discoverPeers());
        actions.addView(scan, weightLp(1));

        Button location = button("LOCATION");
        location.setOnClickListener(v -> openLocationSettings());
        actions.addView(location, weightLp(1));
        root.addView(actions, lp(LinearLayout.LayoutParams.MATCH_PARENT, 55));

        TextView peerTitle = text("NEARBY ASTERION DEVICES", 14, Color.WHITE);
        root.addView(peerTitle, lp(LinearLayout.LayoutParams.MATCH_PARENT, 36));

        peersBox = new LinearLayout(this);
        peersBox.setOrientation(LinearLayout.VERTICAL);
        peersBox.setPadding(0, 0, 0, 6);
        root.addView(peersBox, lp(LinearLayout.LayoutParams.MATCH_PARENT, 150));

        TextView chatTitle = text("CHAT", 14, Color.WHITE);
        root.addView(chatTitle, lp(LinearLayout.LayoutParams.MATCH_PARENT, 34));

        ScrollView scroll = new ScrollView(this);
        chat = text("No messages yet. Connect two phones and say hello.\n", 15, Color.rgb(244, 247, 251));
        chat.setPadding(12, 12, 12, 12);
        chat.setBackgroundColor(Color.rgb(21, 26, 34));
        scroll.addView(chat);
        root.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        inputRow.setPadding(0, 10, 0, 0);

        messageInput = new EditText(this);
        messageInput.setSingleLine(false);
        messageInput.setMaxLines(3);
        messageInput.setHint("Write a message…");
        messageInput.setHintTextColor(Color.rgb(120, 130, 142));
        messageInput.setTextColor(Color.WHITE);
        messageInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        messageInput.setPadding(14, 10, 14, 10);
        messageInput.setBackgroundColor(Color.rgb(28, 35, 48));
        inputRow.addView(messageInput, new LinearLayout.LayoutParams(0, 56, 1f));

        sendButton = button("SEND");
        sendButton.setEnabled(false);
        sendButton.setOnClickListener(v -> sendMessageFromUi());
        inputRow.addView(sendButton, new LinearLayout.LayoutParams(105, 56));
        root.addView(inputRow, lp(LinearLayout.LayoutParams.MATCH_PARENT, 66));

        fileButton = button("SEND FILE");
        fileButton.setEnabled(false);
        fileButton.setOnClickListener(v -> pickFile());
        root.addView(fileButton, lp(LinearLayout.LayoutParams.MATCH_PARENT, 56));

        setContentView(root);
    }

    private LinearLayout.LayoutParams lp(int width, int height) {
        return new LinearLayout.LayoutParams(width, height);
    }

    private LinearLayout.LayoutParams weightLp(float weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, 48, weight);
        p.setMargins(0, 0, 8, 0);
        return p;
    }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(12);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        return b;
    }

    private void setupWifiP2p() {
        manager = (WifiP2pManager) getSystemService(Context.WIFI_P2P_SERVICE);
        if (manager == null) {
            setStatus("Wi-Fi Direct is not supported on this device.");
            return;
        }
        channel = manager.initialize(this, getMainLooper(), () -> setStatus("Wi-Fi Direct channel lost. Reopen the app."));
    }

    private void registerP2pReceiver() {
        if (receiverRegistered) return;
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION.equals(action)) {
                    int state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, WifiP2pManager.WIFI_P2P_STATE_DISABLED);
                    if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED) {
                        setStatus("Wi-Fi Direct ON. Tap Scan Devices.");
                    } else {
                        setStatus("Turn Wi-Fi ON. Internet is NOT required.");
                    }
                } else if (WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(action)) {
                    requestPeers();
                } else if (WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(action)) {
                    if (manager == null || !hasNearbyPermission()) return;
                    NetworkInfo networkInfo = intent.getParcelableExtra(WifiP2pManager.EXTRA_NETWORK_INFO);
                    boolean connectedNow = networkInfo != null && networkInfo.isConnected();
                    if (connectedNow) {
                        manager.requestConnectionInfo(channel, MainActivity.this);
                    }
                }
            }
        };

        IntentFilter filter = new IntentFilter();
        filter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
        filter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        filter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        filter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);

        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(receiver, filter);
        }
        receiverRegistered = true;
    }

    private void requestNeededPermissions() {
        List<String> permissions = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.NEARBY_WIFI_DEVICES);
            }
        } else {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
            }
        }
        if (!permissions.isEmpty()) {
            requestPermissions(permissions.toArray(new String[0]), REQ_PERMISSIONS);
        }
    }

    private boolean hasNearbyPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            return checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void discoverPeers() {
        if (!hasNearbyPermission()) {
            requestNeededPermissions();
            return;
        }
        if (!isLocationEnabled()) {
            setStatus("Android requires Location mode ON for peer discovery. Tap LOCATION.");
            return;
        }
        if (manager == null || channel == null) return;
        setStatus("Scanning nearby devices…");
        manager.discoverPeers(channel, new WifiP2pManager.ActionListener() {
            @Override public void onSuccess() { setStatus("Discovery started. Waiting for devices…"); }
            @Override public void onFailure(int reason) { setStatus("Discovery failed: " + reasonText(reason)); }
        });
    }

    private void requestPeers() {
        if (!hasNearbyPermission() || manager == null || channel == null) return;
        manager.requestPeers(channel, peerListListener);
    }

    private final WifiP2pManager.PeerListListener peerListListener = new WifiP2pManager.PeerListListener() {
        @Override public void onPeersAvailable(WifiP2pDeviceList list) {
            peersBox.removeAllViews();
            if (list.getDeviceList().isEmpty()) {
                peersBox.addView(text("No devices found yet. Put both phones close, Wi-Fi ON, and press Scan.", 13, Color.rgb(154, 166, 178)));
                return;
            }
            for (WifiP2pDevice device : list.getDeviceList()) {
                Button peer = button(device.deviceName + "  •  " + statusText(device.status));
                peer.setOnClickListener(v -> connectTo(device));
                peersBox.addView(peer, lp(LinearLayout.LayoutParams.MATCH_PARENT, 48));
            }
        }
    };

    private void connectTo(WifiP2pDevice device) {
        if (!hasNearbyPermission()) { requestNeededPermissions(); return; }
        WifiP2pConfig config = new WifiP2pConfig();
        config.deviceAddress = device.deviceAddress;
        config.groupOwnerIntent = 6;
        setStatus("Connecting to " + device.deviceName + "…");
        manager.connect(channel, config, new WifiP2pManager.ActionListener() {
            @Override public void onSuccess() { setStatus("Connection request sent. Accept the system prompt if shown."); }
            @Override public void onFailure(int reason) { setStatus("Connect failed: " + reasonText(reason)); }
        });
    }

    @Override
    public void onConnectionInfoAvailable(WifiP2pInfo info) {
        if (!info.groupFormed) return;
        if (info.isGroupOwner) {
            setStatus("Connected. This phone is the Wi-Fi Direct group owner.");
            startServer();
        } else {
            String host = info.groupOwnerAddress != null ? info.groupOwnerAddress.getHostAddress() : null;
            setStatus("Connected. Opening chat link…");
            if (host != null) startClient(host);
        }
    }

    private void startServer() {
        if (connected) return;
        io.execute(() -> {
            try {
                closeServerOnly();
                serverSocket = new ServerSocket(PORT);
                setStatus("Waiting for chat connection…");
                Socket s = serverSocket.accept();
                attachSocket(s);
            } catch (IOException e) {
                setStatus("Server error: " + e.getMessage());
            }
        });
    }

    private void startClient(String host) {
        if (connected) return;
        io.execute(() -> {
            try {
                closeSocketOnly();
                Socket s = new Socket(host, PORT);
                attachSocket(s);
            } catch (IOException e) {
                setStatus("Chat connection failed: " + e.getMessage());
            }
        });
    }

    private void attachSocket(Socket s) throws IOException {
        synchronized (socketLock) {
            closeSocketOnly();
            socket = s;
            input = new DataInputStream(s.getInputStream());
            output = new DataOutputStream(s.getOutputStream());
            connected = true;
        }
        setChatEnabled(true);
        setStatus("CHAT CONNECTED • No Internet • Wi-Fi Direct");
        appendChat("System", "Secure transport is NOT enabled yet in v0.1. This build is for connectivity testing.");
        io.execute(this::readLoop);
    }

    private void readLoop() {
        try {
            while (connected && input != null) {
                String type = input.readUTF();
                if ("MSG".equals(type)) {
                    String message = input.readUTF();
                    appendChat("Peer", message);
                } else if ("FILE".equals(type)) {
                    String name = input.readUTF();
                    long size = input.readLong();
                    File saved = receiveFile(name, size);
                    appendChat("Peer", "📎 File received: " + saved.getAbsolutePath());
                }
            }
        } catch (Exception e) {
            if (connected) {
                connected = false;
                setChatEnabled(false);
                setStatus("Chat disconnected: " + e.getMessage());
            }
        }
    }

    private void sendMessageFromUi() {
        String message = messageInput.getText().toString().trim();
        if (message.isEmpty() || !connected) return;
        messageInput.setText("");
        io.execute(() -> {
            try {
                synchronized (socketLock) {
                    if (output == null) return;
                    output.writeUTF("MSG");
                    output.writeUTF(message);
                    output.flush();
                }
                appendChat("You", message);
            } catch (IOException e) {
                setStatus("Send failed: " + e.getMessage());
            }
        });
    }

    private void pickFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, PICK_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            io.execute(() -> sendFile(uri));
        }
    }

    private void sendFile(Uri uri) {
        if (!connected) return;
        String name = getDisplayName(uri);
        if (name == null || name.trim().isEmpty()) name = "file";
        long size = getFileSize(uri);
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IOException("Could not open file");
            synchronized (socketLock) {
                output.writeUTF("FILE");
                output.writeUTF(name);
                output.writeLong(size);
                byte[] buffer = new byte[64 * 1024];
                long sent = 0;
                int read;
                while ((read = in.read(buffer)) != -1) {
                    output.write(buffer, 0, read);
                    sent += read;
                    if (size > 0) updateProgress("Sending " + name + " • " + Math.min(100, (sent * 100 / size)) + "%");
                }
                output.flush();
            }
            appendChat("You", "📎 File sent: " + name + " (" + humanBytes(size) + ")");
            setStatus("File sent successfully.");
        } catch (Exception e) {
            setStatus("File send failed: " + e.getMessage());
        }
    }

    private File receiveFile(String originalName, long size) throws IOException {
        String safeName = originalName.replaceAll("[^a-zA-Z0-9._ -]", "_");
        if (safeName.length() > 120) safeName = safeName.substring(0, 120);

        if (Build.VERSION.SDK_INT >= 29) {
            android.content.ContentValues values = new android.content.ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Asterion");
            Uri outUri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (outUri == null) throw new IOException("Could not create download file");
            try (OutputStream out = getContentResolver().openOutputStream(outUri)) {
                copyIncoming(out, size);
            }
            return new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Asterion/" + safeName);
        }

        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Asterion");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create receive folder");
        File file = uniqueFile(new File(dir, safeName));
        try (OutputStream out = new FileOutputStream(file)) {
            copyIncoming(out, size);
        }
        return file;
    }

    private void copyIncoming(OutputStream out, long size) throws IOException {
        byte[] buffer = new byte[64 * 1024];
        long received = 0;
        while (received < size) {
            int want = (int) Math.min(buffer.length, size - received);
            int n = input.read(buffer, 0, want);
            if (n < 0) throw new IOException("Connection ended during file transfer");
            out.write(buffer, 0, n);
            received += n;
            if (size > 0) updateProgress("Receiving file • " + Math.min(100, (received * 100 / size)) + "%");
        }
    }

    private File uniqueFile(File target) {
        if (!target.exists()) return target;
        String name = target.getName();
        String base = name;
        String ext = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0) { base = name.substring(0, dot); ext = name.substring(dot); }
        int i = 2;
        File candidate;
        do {
            candidate = new File(target.getParentFile(), base + " (" + i++ + ")" + ext);
        } while (candidate.exists());
        return candidate;
    }

    private String getDisplayName(Uri uri) {
        Cursor c = getContentResolver().query(uri, new String[]{"_display_name"}, null, null, null);
        if (c == null) return null;
        try { return c.moveToFirst() ? c.getString(0) : null; }
        finally { c.close(); }
    }

    private long getFileSize(Uri uri) {
        Cursor c = getContentResolver().query(uri, new String[]{"_size"}, null, null, null);
        if (c == null) return 0;
        try { return c.moveToFirst() ? c.getLong(0) : 0; }
        finally { c.close(); }
    }

    private void setChatEnabled(boolean enabled) {
        runOnUiThread(() -> {
            sendButton.setEnabled(enabled);
            fileButton.setEnabled(enabled);
        });
    }

    private void setStatus(String s) {
        runOnUiThread(() -> status.setText(s));
    }

    private void updateProgress(String s) {
        runOnUiThread(() -> status.setText(s));
    }

    private void appendChat(String who, String message) {
        runOnUiThread(() -> {
            chat.append("\n" + who + ": " + message + "\n");
            chat.post(() -> ((ScrollView) chat.getParent()).fullScroll(View.FOCUS_DOWN));
        });
    }

    private void openLocationSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        } catch (Exception ignored) {}
    }

    private boolean isLocationEnabled() {
        if (Build.VERSION.SDK_INT < 23) return true;
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return false;
        try { return lm.isLocationEnabled(); }
        catch (Exception e) { return false; }
    }

    private String statusText(int status) {
        switch (status) {
            case WifiP2pDevice.AVAILABLE: return "available";
            case WifiP2pDevice.INVITED: return "invited";
            case WifiP2pDevice.CONNECTED: return "connected";
            case WifiP2pDevice.FAILED: return "failed";
            case WifiP2pDevice.UNAVAILABLE: return "unavailable";
            default: return "unknown";
        }
    }

    private String reasonText(int reason) {
        switch (reason) {
            case WifiP2pManager.P2P_UNSUPPORTED: return "P2P unsupported";
            case WifiP2pManager.BUSY: return "busy";
            case WifiP2pManager.ERROR: return "framework error";
            default: return String.valueOf(reason);
        }
    }

    private String humanBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.US, "%.1f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024L * 1024L) return String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
        return String.format(Locale.US, "%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }

    private void closeServerOnly() {
        if (serverSocket != null) {
            try { serverSocket.close(); } catch (IOException ignored) {}
            serverSocket = null;
        }
    }

    private void closeSocketOnly() {
        connected = false;
        try { if (input != null) input.close(); } catch (IOException ignored) {}
        try { if (output != null) output.close(); } catch (IOException ignored) {}
        try { if (socket != null) socket.close(); } catch (IOException ignored) {}
        input = null;
        output = null;
        socket = null;
    }

    @Override
    protected void onDestroy() {
        closeSocketOnly();
        closeServerOnly();
        io.shutdownNow();
        if (receiverRegistered) {
            try { unregisterReceiver(receiver); } catch (Exception ignored) {}
            receiverRegistered = false;
        }
        if (manager != null && channel != null && hasNearbyPermission()) {
            try { manager.stopPeerDiscovery(channel, null); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMISSIONS) {
            boolean ok = true;
            for (int r : grantResults) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
            setStatus(ok ? "Permission ready. Turn Wi-Fi ON, Location ON, then Scan." : "Nearby Wi-Fi permission was denied.");
        }
    }
}
