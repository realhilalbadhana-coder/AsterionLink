# Asterion Link 5.1

Local, offline phone-to-phone messenger. Wi-Fi Direct discovery, profile
sharing, real-time chat, and file transfer — no SIM, no mobile data,
no internet, no server.

## What changed in 5.1

**Fixed — compile error.** Five layout calls passed 3 arguments (width,
height, weight) to `lp()`, a helper defined to take only 2. A second helper,
`lpWeighted(w, h, weight)`, already existed for exactly this case but was
never called anywhere. Those 5 call sites now correctly call `lpWeighted(...)`.

**Fixed — discovery stopped working after Back.** `startWifiDirect()` used to
return early with `if (pm != null) return;` before it ever reached the
peer-scan call. That guard was meant to stop Wi-Fi Direct from being
re-initialized on every visit to Home, but it also silently skipped
re-scanning for peers — so after pressing Back once, the device list would
never refresh again. The guard now only wraps one-time setup (manager init,
broadcast receiver, TCP server); peer discovery restarts every time Home is
shown.

**Design.** New visual identity: indigo-night splash with an amber "beacon"
mark (signal rings around a solid core) instead of a generic circular logo,
asymmetric chat bubbles (solid accent for sent, outlined for received),
signal-accent bar on nearby-device rows instead of a plain bordered card,
and a real empty state on the device list instead of blank space.

## Known follow-ups (not yet done)

- File transfer still buffers the whole file into memory (capped at 20 MB)
  rather than streaming — fine for the MVP, worth revisiting for larger files.
- Chat messages aren't persisted; they clear if you leave and reopen a chat.
- Everything lives in one Activity/file, by design for this MVP stage — a
  future pass could split Discovery/Transport/Persistence into separate
  classes without changing behavior.

## Build

GitHub Actions workflow (`.github/workflows/build.yml`) builds a debug APK
on `workflow_dispatch` using JDK 17 and Android SDK 35. No local Android SDK
required — trigger the workflow from GitHub's Actions tab.
