package com.asterion.link;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.net.Uri;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Asterion Link — local, offline phone-to-phone messenger over Wi-Fi Direct.
 * No SIM, no mobile data, no internet, no server. Two nearby devices discover
 * each other, connect directly, and exchange text + files over a plain TCP
 * socket running on top of the Wi-Fi Direct link.
 *
 * Single-Activity MVP: the UI is built programmatically (no layout XML) to
 * keep the whole networking + UI lifecycle in one place while the app is
 * still young. Frame-type constants define the wire protocol (see sendFrame).
 */
public class MainActivity extends Activity {

    // ---- wire protocol ----------------------------------------------------
    static final int PORT = 8988;
    static final byte FRAME_PROFILE = 1;
    static final byte FRAME_TEXT = 2;
    static final byte FRAME_FILE = 3;

    // ---- permission / activity request codes ------------------------------
    static final int REQ_NEARBY_PERMISSION = 41;
    static final int REQ_PICK_PHOTO = 42;
    static final int REQ_PICK_FILE = 43;

    static final long FILE_SIZE_LIMIT = 20L * 1024 * 1024;

    // ---- design tokens ------------------------------------------------------
    final int PAPER = Color.rgb(0xF7, 0xF6, 0xF3);
    final int SURFACE = Color.WHITE;
    final int INK = Color.rgb(0x12, 0x13, 0x1A);
    final int MUTED = Color.rgb(0x6F, 0x6C, 0x80);
    final int LINE = Color.rgb(0xE7, 0xE4, 0xE0);
    final int ACCENT = Color.rgb(0xFF, 0x8A, 0x3D);
    final int ACCENT_SOFT = Color.rgb(0xFF, 0xE8, 0xD6);
    final int NIGHT = Color.rgb(0x12, 0x13, 0x1A);

    // ---- Wi-Fi Direct -------------------------------------------------------
    WifiP2pManager p2pManager;
    WifiP2pManager.Channel p2pChannel;
    BroadcastReceiver p2pReceiver;
    boolean p2pInitialized = false;
    final ArrayList<WifiP2pDevice> devices = new ArrayList<>();

    // ---- profile --------------------------------------------------------
    SharedPreferences prefs;
    String myName = "";
    byte[] myPhoto;
    String peerName = "Asterion device";
    byte[] peerPhoto;

    // ---- socket / transport -------------------------------------------------
    Socket socket;
    ServerSocket serverSocket;
    DataInputStream in;
    DataOutputStream out;
    final Object writeLock = new Object();
    final ExecutorService pool = Executors.newCachedThreadPool();
    final Handler ui = new Handler(Looper.getMainLooper());
    volatile boolean connected = false;
    boolean inChat = false;

    // ---- view refs ------------------------------------------------------
    LinearLayout root, deviceList, messageColumn;
    ScrollView chatScroll;
    TextView chatPeerName, chatPeerStatus;
    ImageView chatPeerAvatar;
    EditText messageInput;
    SoundPool soundPool;
    int popSoundId;

    // ======================================================================
    // layout helpers
    // ======================================================================

    int dp(float x) {
        return (int) (x * getResources().getDisplayMetrics().density + 0.5f);
    }

    TextView text(String s, float sizeSp, int color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sizeSp);
        v.setTextColor(color);
        return v;
    }

    /** Fixed-size layout params (width/height only). */
    LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    /** Weighted layout params — for flexible/expanding children in a LinearLayout row or column. */
    LinearLayout.LayoutParams lpWeighted(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    GradientDrawable roundedFill(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    GradientDrawable roundedOutline(int fill, int strokeColor, float radiusDp) {
        GradientDrawable g = roundedFill(fill, radiusDp);
        g.setStroke(dp(1), strokeColor);
        return g;
    }

    void margin(View v, int l, int top, int r, int b) {
        ViewGroup.LayoutParams q = v.getLayoutParams();
        if (q instanceof LinearLayout.LayoutParams) {
            ((LinearLayout.LayoutParams) q).setMargins(dp(l), dp(top), dp(r), dp(b));
            v.setLayoutParams(q);
        }
    }

    // ======================================================================
    // lifecycle
    // ======================================================================

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(PAPER);
        getWindow().setNavigationBarColor(PAPER);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        prefs = getSharedPreferences("profile", 0);
        loadProfile();

        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        soundPool = new SoundPool.Builder().setMaxStreams(2).setAudioAttributes(attrs).build();
        popSoundId = soundPool.load(this, R.raw.message_pop, 1);

        showSplash();
    }

    void loadProfile() {
        myName = prefs.getString("name", "");
        String photoPath = prefs.getString("photo", "");
        if (!photoPath.isEmpty()) {
            try {
                myPhoto = readAll(new FileInputStream(photoPath));
            } catch (Exception ignored) {
                // no saved photo yet — fine, splash/profile screen handles the empty case
            }
        }
    }

    byte[] readAll(InputStream stream) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] chunk = new byte[8192];
        int n;
        while ((n = stream.read(chunk)) > 0) buffer.write(chunk, 0, n);
        return buffer.toByteArray();
    }

    // ======================================================================
    // splash
    // ======================================================================

    void showSplash() {
        LinearLayout s = new LinearLayout(this);
        s.setOrientation(LinearLayout.VERTICAL);
        s.setGravity(Gravity.CENTER);
        s.setBackgroundColor(NIGHT);

        ImageView mark = new ImageView(this);
        mark.setImageResource(R.drawable.ic_asterion);
        s.addView(mark, lp(dp(88), dp(88)));
        margin(mark, 0, 0, 0, 22);

        TextView line1 = text("ASTERION", 15, ACCENT);
        line1.setLetterSpacing(0.22f);
        line1.setGravity(Gravity.CENTER);
        line1.setTypeface(null, android.graphics.Typeface.BOLD);
        s.addView(line1, lp(-1, dp(22)));
        margin(line1, 0, 0, 0, 2);

        TextView line2 = text("Link", 34, SURFACE);
        line2.setGravity(Gravity.CENTER);
        line2.setTypeface(null, android.graphics.Typeface.BOLD);
        s.addView(line2, lp(-1, dp(46)));
        margin(line2, 0, 0, 0, 16);

        TextView tag = text("No SIM. No internet. Just nearby.", 13, Color.rgb(0xB8, 0xB5, 0xC4));
        tag.setGravity(Gravity.CENTER);
        s.addView(tag, lp(-1, dp(22)));

        setContentView(s);
        ui.postDelayed(() -> {
            if (myName.isEmpty()) showProfileScreen(false);
            else showHome();
        }, 900);
    }

    // ======================================================================
    // profile
    // ======================================================================

    void showProfileScreen(boolean editing) {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(24), dp(26), dp(24), dp(24));
        p.setBackgroundColor(PAPER);

        if (editing) {
            TextView back = text("\u2039", 32, INK);
            back.setGravity(Gravity.CENTER);
            back.setTypeface(null, android.graphics.Typeface.BOLD);
            p.addView(back, lp(dp(44), dp(44)));
            back.setOnClickListener(v -> showHome());
        }

        TextView heading = text(editing ? "Your profile" : "Create your profile", 26, INK);
        heading.setTypeface(null, android.graphics.Typeface.BOLD);
        p.addView(heading, lp(-1, dp(46)));
        margin(heading, 0, editing ? 8 : 30, 0, 0);

        TextView subtitle = text(
                editing ? "This is what nearby devices see." : "Choose the name and photo nearby devices will see.",
                14, MUTED);
        subtitle.setLineSpacing(0, 1.2f);
        p.addView(subtitle, lp(-1, dp(48)));
        margin(subtitle, 0, 6, 0, 0);

        FrameAvatar avatarFrame = buildAvatar(myPhoto, 100);
        p.addView(avatarFrame.view, lp(dp(100), dp(100)));
        margin(avatarFrame.view, 0, 24, 0, 8);

        TextView choosePhoto = text("Add profile photo", 14, ACCENT);
        choosePhoto.setGravity(Gravity.CENTER);
        choosePhoto.setTypeface(null, android.graphics.Typeface.BOLD);
        p.addView(choosePhoto, lp(dp(170), dp(36)));
        choosePhoto.setOnClickListener(v -> pickPhoto());

        EditText nameInput = new EditText(this);
        nameInput.setText(myName);
        nameInput.setHint("Your name");
        nameInput.setSingleLine(true);
        nameInput.setTextSize(17);
        nameInput.setTextColor(INK);
        nameInput.setHintTextColor(MUTED);
        nameInput.setPadding(dp(16), 0, dp(16), 0);
        nameInput.setBackground(roundedOutline(SURFACE, LINE, 14));
        p.addView(nameInput, lp(-1, dp(54)));
        margin(nameInput, 0, 26, 0, 0);

        Space flexSpace = new Space(this);
        p.addView(flexSpace, lpWeighted(-1, 0, 1));

        Button save = new Button(this);
        save.setText(editing ? "Save changes" : "Continue");
        save.setTextSize(15);
        save.setTextColor(SURFACE);
        save.setAllCaps(false);
        save.setTypeface(null, android.graphics.Typeface.BOLD);
        save.setBackground(roundedFill(ACCENT, 16));
        p.addView(save, lp(-1, dp(56)));
        save.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            if (name.isEmpty()) {
                nameInput.setError("Enter your name");
                return;
            }
            myName = name;
            prefs.edit().putString("name", myName).apply();
            if (myPhoto != null) {
                try {
                    File f = new File(getFilesDir(), "profile.jpg");
                    FileOutputStream o = new FileOutputStream(f);
                    o.write(myPhoto);
                    o.close();
                    prefs.edit().putString("photo", f.getAbsolutePath()).apply();
                } catch (Exception ignored) {
                    // profile still saves without the photo
                }
            }
            showHome();
        });

        setContentView(p);
    }

    void pickPhoto() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, REQ_PICK_PHOTO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;

        if (requestCode == REQ_PICK_PHOTO) {
            try {
                Bitmap b = BitmapFactory.decodeStream(getContentResolver().openInputStream(data.getData()));
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                b.compress(Bitmap.CompressFormat.JPEG, 82, o);
                myPhoto = o.toByteArray();
                showProfileScreen(false);
            } catch (Exception e) {
                Toast.makeText(this, "Photo could not be loaded", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == REQ_PICK_FILE) {
            sendFile(data.getData());
        }
    }

    // Small helper bundling an ImageView styled as a circular-ish avatar frame.
    static class FrameAvatar {
        ImageView view;
    }

    FrameAvatar buildAvatar(byte[] photoBytes, float sizeDp) {
        ImageView iv = new ImageView(this);
        iv.setImageResource(R.drawable.ic_asterion);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackground(roundedFill(ACCENT_SOFT, sizeDp / 2f));
        iv.setClipToOutline(true);
        if (photoBytes != null) setPhoto(iv, photoBytes);
        FrameAvatar fa = new FrameAvatar();
        fa.view = iv;
        return fa;
    }

    void setPhoto(ImageView v, byte[] bytes) {
        Bitmap b = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        if (b != null) v.setImageBitmap(b);
    }

    // ======================================================================
    // home
    // ======================================================================

    void showHome() {
        inChat = false;
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(PAPER);
        setContentView(root);

        buildHomeHeader();

        ScrollView sv = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(16), dp(18), dp(18));

        TextView sectionLabel = text("Nearby devices", 13, MUTED);
        sectionLabel.setLetterSpacing(0.08f);
        sectionLabel.setTypeface(null, android.graphics.Typeface.BOLD);
        body.addView(sectionLabel, lp(-1, dp(24)));
        margin(sectionLabel, 0, 0, 0, 10);

        deviceList = new LinearLayout(this);
        deviceList.setOrientation(LinearLayout.VERTICAL);
        body.addView(deviceList, lp(-1, -2));

        sv.addView(body);
        root.addView(sv, lpWeighted(-1, 0, 1));

        startWifiDirect();
    }

    void buildHomeHeader() {
        LinearLayout h = new LinearLayout(this);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(dp(18), dp(14), dp(14), dp(14));
        h.setBackgroundColor(NIGHT);

        ImageView mark = new ImageView(this);
        mark.setImageResource(R.drawable.ic_asterion);
        h.addView(mark, lp(dp(38), dp(38)));
        margin(mark, 0, 0, 12, 0);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("Asterion Link", 18, SURFACE);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView subtitle = text("Offline \u00b7 local only", 12, Color.rgb(0xB8, 0xB5, 0xC4));
        titles.addView(title, lp(-1, dp(24)));
        titles.addView(subtitle, lp(-1, dp(18)));
        h.addView(titles, lpWeighted(0, dp(46), 1));

        TextView me = text(myName.isEmpty() ? "Me" : myName, 13, ACCENT);
        me.setGravity(Gravity.CENTER);
        me.setBackground(roundedOutline(Color.argb(40, 255, 138, 61), ACCENT, 14));
        h.addView(me, lp(dp(90), dp(36)));
        me.setOnClickListener(v -> showProfileScreen(true));

        root.addView(h, lp(-1, dp(68)));
    }

    void renderDeviceList() {
        if (deviceList == null) return;
        deviceList.removeAllViews();

        if (devices.isEmpty()) {
            LinearLayout empty = new LinearLayout(this);
            empty.setOrientation(LinearLayout.VERTICAL);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(20), dp(36), dp(20), dp(36));
            TextView e1 = text("Looking for nearby devices", 15, INK);
            e1.setGravity(Gravity.CENTER);
            e1.setTypeface(null, android.graphics.Typeface.BOLD);
            TextView e2 = text("Keep Wi-Fi on. Nearby Asterion Link phones appear here automatically.", 13, MUTED);
            e2.setGravity(Gravity.CENTER);
            e2.setLineSpacing(0, 1.2f);
            empty.addView(e1, lp(-1, dp(22)));
            empty.addView(e2, lp(-1, -2));
            margin(e2, 24, 6, 24, 0);
            deviceList.addView(empty, lp(-1, -2));
            return;
        }

        for (WifiP2pDevice device : devices) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(12), dp(12), dp(12));
            row.setBackground(roundedOutline(SURFACE, LINE, 16));

            // signal-accent bar on the leading edge instead of a generic full border
            View accentBar = new View(this);
            accentBar.setBackgroundColor(device.status == WifiP2pDevice.AVAILABLE ? ACCENT : LINE);
            row.addView(accentBar, lp(dp(3), dp(40)));
            margin(accentBar, 0, 0, 12, 0);

            FrameAvatar avatar = buildAvatar(null, 44);
            row.addView(avatar.view, lp(dp(44), dp(44)));
            margin(avatar.view, 0, 0, 12, 0);

            LinearLayout labels = new LinearLayout(this);
            labels.setOrientation(LinearLayout.VERTICAL);
            String name = device.deviceName == null ? "Asterion device" : device.deviceName;
            TextView n = text(name, 16, INK);
            n.setTypeface(null, android.graphics.Typeface.BOLD);
            TextView status = text(device.status == WifiP2pDevice.AVAILABLE ? "Available" : "Nearby", 12, MUTED);
            labels.addView(n, lp(-1, dp(22)));
            labels.addView(status, lp(-1, dp(18)));
            row.addView(labels, lpWeighted(0, dp(46), 1));

            TextView connect = text("Connect", 13, ACCENT);
            connect.setGravity(Gravity.CENTER);
            connect.setTypeface(null, android.graphics.Typeface.BOLD);
            connect.setBackground(roundedOutline(ACCENT_SOFT, ACCENT_SOFT, 14));
            row.addView(connect, lp(dp(88), dp(38)));
            connect.setOnClickListener(v -> {
                peerName = name;
                openChat();
                WifiP2pConfig cfg = new WifiP2pConfig();
                cfg.deviceAddress = device.deviceAddress;
                p2pManager.connect(p2pChannel, cfg, new WifiP2pManager.ActionListener() {
                    public void onSuccess() {}
                    public void onFailure(int reason) {
                        Toast.makeText(MainActivity.this, "Connection failed: " + reason, Toast.LENGTH_SHORT).show();
                    }
                });
            });

            deviceList.addView(row, lp(-1, dp(72)));
            margin(row, 0, 0, 0, 10);
        }
    }

    // ======================================================================
    // chat
    // ======================================================================

    void openChat() {
        inChat = true;
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(PAPER);
        setContentView(root);

        LinearLayout h = new LinearLayout(this);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(dp(6), dp(10), dp(14), dp(10));
        h.setBackgroundColor(SURFACE);

        TextView back = text("\u2039", 32, INK);
        back.setGravity(Gravity.CENTER);
        h.addView(back, lp(dp(40), dp(48)));
        back.setOnClickListener(v -> showHome());

        FrameAvatar avatarFrame = buildAvatar(peerPhoto, 40);
        chatPeerAvatar = avatarFrame.view;
        h.addView(chatPeerAvatar, lp(dp(40), dp(40)));
        margin(chatPeerAvatar, 0, 0, 10, 0);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        chatPeerName = text(peerName, 16, INK);
        chatPeerName.setTypeface(null, android.graphics.Typeface.BOLD);
        chatPeerStatus = text("Waiting for connection\u2026", 12, MUTED);
        titles.addView(chatPeerName, lp(-1, dp(24)));
        titles.addView(chatPeerStatus, lp(-1, dp(18)));
        h.addView(titles, lpWeighted(0, dp(46), 1));

        root.addView(h, lp(-1, dp(66)));

        chatScroll = new ScrollView(this);
        messageColumn = new LinearLayout(this);
        messageColumn.setOrientation(LinearLayout.VERTICAL);
        messageColumn.setPadding(dp(14), dp(16), dp(14), dp(16));
        chatScroll.addView(messageColumn);
        root.addView(chatScroll, lpWeighted(-1, 0, 1));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(8), dp(10), dp(8));
        bar.setBackgroundColor(SURFACE);

        ImageButton attach = new ImageButton(this);
        attach.setImageResource(R.drawable.ic_attach);
        attach.setBackgroundColor(Color.TRANSPARENT);
        bar.addView(attach, lp(dp(44), dp(48)));
        attach.setOnClickListener(v -> pickFile());

        messageInput = new EditText(this);
        messageInput.setHint("Message");
        messageInput.setSingleLine(true);
        messageInput.setTextSize(15);
        messageInput.setTextColor(INK);
        messageInput.setHintTextColor(MUTED);
        messageInput.setPadding(dp(16), 0, dp(16), 0);
        messageInput.setBackground(roundedFill(PAPER, 22));
        bar.addView(messageInput, lpWeighted(0, dp(48), 1));

        ImageButton send = new ImageButton(this);
        send.setImageResource(R.drawable.ic_send);
        send.setBackground(roundedFill(ACCENT, 50));
        bar.addView(send, lp(dp(48), dp(48)));
        margin(send, 8, 0, 0, 0);
        send.setOnClickListener(v -> sendText());

        root.addView(bar, lp(-1, dp(64)));

        updateChatStatus();
    }

    void addBubble(String message, boolean mine) {
        if (messageColumn == null) return;
        LinearLayout row = new LinearLayout(this);
        row.setGravity(mine ? Gravity.RIGHT : Gravity.LEFT);

        TextView bubble = text(message, 15, mine ? SURFACE : INK);
        bubble.setPadding(dp(14), dp(10), dp(14), dp(10));
        // asymmetric bubble style: sent = solid accent, received = outlined ghost
        bubble.setBackground(mine ? roundedFill(ACCENT, 16) : roundedOutline(SURFACE, LINE, 16));

        int maxWidth = Math.min(dp(300), getResources().getDisplayMetrics().widthPixels - dp(70));
        row.addView(bubble, lp(maxWidth, -2));
        messageColumn.addView(row, lp(-1, -2));
        margin(row, 0, 4, 0, 4);

        chatScroll.post(() -> chatScroll.fullScroll(View.FOCUS_DOWN));
    }

    void sendText() {
        String s = messageInput.getText().toString().trim();
        if (s.isEmpty()) return;
        if (!connected) {
            Toast.makeText(this, "Not connected yet", Toast.LENGTH_SHORT).show();
            return;
        }
        sendFrame(FRAME_TEXT, s.getBytes(StandardCharsets.UTF_8));
        addBubble(s, true);
        messageInput.setText("");
    }

    void updateChatStatus() {
        if (chatPeerStatus == null) return;
        chatPeerStatus.setText(connected ? "Connected \u00b7 Wi-Fi Direct" : "Waiting for connection\u2026");
        chatPeerStatus.setTextColor(connected ? ACCENT : MUTED);
    }

    // ======================================================================
    // file transfer
    // ======================================================================

    void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, REQ_PICK_FILE);
    }

    void sendFile(Uri uri) {
        if (!connected) return;
        pool.execute(() -> {
            try {
                String name = "file";
                Cursor c = getContentResolver().query(uri, null, null, null, null);
                if (c != null) {
                    int col = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                    if (c.moveToFirst() && col >= 0) name = c.getString(col);
                    c.close();
                }
                byte[] data = readAll(getContentResolver().openInputStream(uri));
                if (data.length > FILE_SIZE_LIMIT) {
                    ui.post(() -> Toast.makeText(this, "File limit is 20 MB", Toast.LENGTH_SHORT).show());
                    return;
                }
                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                DataOutputStream w = new DataOutputStream(buffer);
                w.writeUTF(name);
                w.writeInt(data.length);
                w.write(data);
                w.close();
                sendFrame(FRAME_FILE, buffer.toByteArray());
                final String shownName = name;
                ui.post(() -> addBubble("\ud83d\udcce " + shownName, true));
            } catch (Exception e) {
                ui.post(() -> Toast.makeText(this, "File send failed", Toast.LENGTH_SHORT).show());
            }
        });
    }

    void handleIncomingFile(byte[] data) {
        try {
            DataInputStream r = new DataInputStream(new ByteArrayInputStream(data));
            String name = r.readUTF();
            int len = r.readInt();
            byte[] file = new byte[len];
            r.readFully(file);
            File dir = getExternalFilesDir("received");
            if (dir != null && !dir.exists()) dir.mkdirs();
            File out = new File(dir, name.replaceAll("[^a-zA-Z0-9._-]", "_"));
            FileOutputStream o = new FileOutputStream(out);
            o.write(file);
            o.close();
            ui.post(() -> {
                addBubble("\ud83d\udcce Received: " + out.getName(), false);
                if (popSoundId != 0) soundPool.play(popSoundId, 0.65f, 0.65f, 1, 0, 1);
                Toast.makeText(this, "File received", Toast.LENGTH_SHORT).show();
            });
        } catch (Exception ignored) {
            // malformed frame — drop it, connection stays open for the next one
        }
    }

    // ======================================================================
    // Wi-Fi Direct discovery + connection lifecycle
    // ======================================================================

    /**
     * Starts (or resumes) Wi-Fi Direct: requests permission if needed, initializes
     * the manager + broadcast receiver exactly once, starts the TCP server exactly
     * once, and (re)starts peer discovery every time this is called — including
     * every time Home is shown again after Back. Re-scanning must never be skipped
     * just because the manager was already initialized on an earlier visit.
     */
    void startWifiDirect() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.NEARBY_WIFI_DEVICES}, REQ_NEARBY_PERMISSION);
            return;
        }
        if (Build.VERSION.SDK_INT <= 32
                && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_NEARBY_PERMISSION);
            return;
        }

        if (!p2pInitialized) {
            p2pManager = (WifiP2pManager) getSystemService(WIFI_P2P_SERVICE);
            p2pChannel = p2pManager.initialize(this, getMainLooper(), null);
            p2pReceiver = new BroadcastReceiver() {
                public void onReceive(Context c, Intent i) {
                    String action = i.getAction();
                    if (WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(action)) {
                        p2pManager.requestPeers(p2pChannel, peers -> {
                            devices.clear();
                            devices.addAll(peers.getDeviceList());
                            renderDeviceList();
                        });
                    } else if (WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(action)) {
                        p2pManager.requestConnectionInfo(p2pChannel, info -> {
                            if (info.groupFormed) {
                                if (!info.isGroupOwner) connectSocket(info.groupOwnerAddress.getHostAddress());
                            } else {
                                connected = false;
                                updateChatStatus();
                            }
                        });
                    }
                }
            };
            IntentFilter filter = new IntentFilter();
            filter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
            filter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(p2pReceiver, filter, Context.RECEIVER_EXPORTED);
            else registerReceiver(p2pReceiver, filter);

            startServer();
            p2pInitialized = true;
        }

        // Always re-scan, even on repeat visits to Home — this is what keeps
        // discovery alive after Back instead of silently going stale.
        scanForPeers();
    }

    void scanForPeers() {
        if (p2pManager == null) return;
        p2pManager.discoverPeers(p2pChannel, new WifiP2pManager.ActionListener() {
            public void onSuccess() {}
            public void onFailure(int reason) {
                Toast.makeText(MainActivity.this, "Scan failed: " + reason, Toast.LENGTH_SHORT).show();
            }
        });
    }

    void startServer() {
        pool.execute(() -> {
            try {
                serverSocket = new ServerSocket(PORT);
                while (!isFinishing()) {
                    Socket incoming = serverSocket.accept();
                    attach(incoming);
                }
            } catch (Exception ignored) {
                // server loop ends on close/finish — expected during teardown
            }
        });
    }

    void connectSocket(String host) {
        pool.execute(() -> {
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(host, PORT), 6000);
                attach(s);
            } catch (Exception ignored) {
                // connection attempt failed — the peer list / reconnect flow handles retry
            }
        });
    }

    void attach(Socket newSocket) {
        try {
            if (socket != null) socket.close();
        } catch (Exception ignored) {}
        socket = newSocket;
        try {
            in = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            out = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
            connected = true;
            ui.post(this::updateChatStatus);
            sendMyProfile();
            readLoop();
        } catch (Exception e) {
            disconnect();
        }
    }

    void sendMyProfile() {
        try {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            DataOutputStream w = new DataOutputStream(buffer);
            byte[] nameBytes = myName.getBytes(StandardCharsets.UTF_8);
            w.writeInt(nameBytes.length);
            w.write(nameBytes);
            byte[] photoBytes = myPhoto == null ? new byte[0] : myPhoto;
            w.writeInt(photoBytes.length);
            w.write(photoBytes);
            w.close();
            sendRaw(FRAME_PROFILE, buffer.toByteArray());
        } catch (Exception e) {
            disconnect();
        }
    }

    void sendRaw(byte type, byte[] data) throws IOException {
        if (out == null) return;
        synchronized (writeLock) {
            out.writeByte(type);
            out.writeInt(data.length);
            out.write(data);
            out.flush();
        }
    }

    void sendFrame(byte type, byte[] data) {
        pool.execute(() -> {
            try {
                sendRaw(type, data);
            } catch (Exception e) {
                disconnect();
            }
        });
    }

    void readLoop() {
        pool.execute(() -> {
            try {
                while (socket != null && !socket.isClosed()) {
                    byte type = in.readByte();
                    int len = in.readInt();
                    if (len < 0 || len > 25 * 1024 * 1024) throw new IOException("bad frame length");
                    byte[] data = new byte[len];
                    in.readFully(data);
                    if (type == FRAME_PROFILE) {
                        handlePeerProfile(data);
                    } else if (type == FRAME_TEXT) {
                        String s = new String(data, StandardCharsets.UTF_8);
                        ui.post(() -> {
                            addBubble(s, false);
                            if (popSoundId != 0) soundPool.play(popSoundId, 0.65f, 0.65f, 1, 0, 1);
                        });
                    } else if (type == FRAME_FILE) {
                        handleIncomingFile(data);
                    }
                }
            } catch (Exception e) {
                disconnect();
            }
        });
    }

    void handlePeerProfile(byte[] data) {
        try {
            DataInputStream r = new DataInputStream(new ByteArrayInputStream(data));
            int nameLen = r.readInt();
            byte[] nameBytes = new byte[nameLen];
            r.readFully(nameBytes);
            int photoLen = r.readInt();
            byte[] photoBytes = new byte[photoLen];
            if (photoLen > 0) r.readFully(photoBytes);
            peerName = new String(nameBytes, StandardCharsets.UTF_8);
            peerPhoto = photoLen > 0 ? photoBytes : null;
            ui.post(() -> {
                if (chatPeerName != null) chatPeerName.setText(peerName);
                if (chatPeerAvatar != null && peerPhoto != null) setPhoto(chatPeerAvatar, peerPhoto);
            });
        } catch (Exception ignored) {
            // malformed profile frame — keep the previous name/photo
        }
    }

    void disconnect() {
        connected = false;
        ui.post(this::updateChatStatus);
    }

    // ======================================================================
    // Activity lifecycle plumbing
    // ======================================================================

    @Override
    public void onBackPressed() {
        if (inChat) showHome();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        try {
            if (p2pReceiver != null) unregisterReceiver(p2pReceiver);
        } catch (Exception ignored) {}
        try {
            if (socket != null) socket.close();
        } catch (Exception ignored) {}
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (Exception ignored) {}
        pool.shutdownNow();
        if (soundPool != null) soundPool.release();
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NEARBY_PERMISSION
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startWifiDirect();
        }
    }
}
